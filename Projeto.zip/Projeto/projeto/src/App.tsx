import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     <div>
  <div>
    <h1>Lista de tarefas</h1>
  </div>
  <div>
    <input type="text" placeholder="informe a tarefa" />
    <button>Adicionar</button>
  </div>
  <ul>
    <li>
      <div>
        <input type="checkbox" name="tarefa_1" id="tarefa_1" />
        <label htmlFor="tarefa_1">
          <span>Front-end web</span>
          <span>Construir um front-end sem estilo</span>
        </label>
      </div>
    </li>
    <li>
      <div>
        <input type="checkbox" name="tarefa_1" id="tarefa_1" />
        <label htmlFor="tarefa_1">
          <span>Montar estilo do Front-end web</span>
          <span>Usar framewerk CSS para estilizar o front-end</span>
        </label>
      </div>
    </li>
  </ul>
</div>

    </>
  )
}

export default App
